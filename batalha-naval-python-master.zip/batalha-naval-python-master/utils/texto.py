def gera_texto(texto):
    return texto