def adiciona_cor(cor, texto):
    return f'\033[{cor}{texto}\033[0;0m'
